<?php
$config = [
    'token' => '7489184507:AAEra4QobhAyNhx3YYgJ7FoqjNH8mSwqxvE',
    'chat_id' => '-4546224680'
];
header('Content-Type: application/json');
echo json_encode($config);
?>
